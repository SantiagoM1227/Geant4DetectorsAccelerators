{
gROOT -> Reset();
TFile f("brachytherapy.root");
TCanvas* c1 = new TCanvas("c1", " ");
h20->Draw("");					   
}
