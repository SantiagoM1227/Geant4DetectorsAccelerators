#include "EnergyTimeHit.hh"
 
G4ThreadLocal G4Allocator<EnergyTimeHit>* hitAllocator = nullptr;